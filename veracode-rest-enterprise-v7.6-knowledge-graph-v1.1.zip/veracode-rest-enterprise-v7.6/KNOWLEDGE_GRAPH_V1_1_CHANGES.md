# Knowledge Graph v1.1 changes

This build improves `vulnerability-paths.json` enrichment without adding external dependencies or performing vulnerability discovery.

## Improvements
- Deep/nested extraction for file path, method/function, line, source, and sink fields commonly present in Veracode-derived JSON.
- Safer repository path resolution, including unique basename/suffix fallback for packaged scan paths.
- Broad language/technology detection for Java/JVM, .NET, JavaScript/TypeScript, Python, Ruby, PHP, Go, Rust, Swift/Objective-C, C/C++, SQL/PLSQL, COBOL, Perl, shell/PowerShell, Salesforce Apex/Visualforce, JSP/ASP.NET, ColdFusion, Dart, Elixir/Erlang, Lua, R, Solidity, and common web files.
- `file_path`, `language`, `technology`, `file_resolved`, `reported_path`, `evidence`, and `missing_evidence` fields in each vulnerability path.
- Compact call-stack/data-path extraction when such rows are embedded in the authoritative results JSON.
- Existing per-run source-file cache retained for efficiency; only finding-referenced files are analyzed.

## Safety / limitations
- No vulnerability discovery is added.
- Missing source/sink/method values are not invented. They are listed in `missing_evidence`.
- Syntax call extraction remains contextual only and is not treated as proof of taint/data flow.
- Rich source/sink information can only be emitted when it exists in the supplied authoritative results JSON (or an upstream enrichment stage adds it).
