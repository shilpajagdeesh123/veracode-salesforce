#!/usr/bin/env python3
"""Focused repository-local knowledge graph builder for Veracode remediation.

No external dependencies. It reads one authoritative results.json and only the
source files referenced by findings. It never performs vulnerability discovery.
"""
import argparse, json, re, os
from pathlib import Path
from datetime import datetime, timezone
from typing import Any

SEV = {5:'Critical',4:'High',3:'Medium',2:'Low',1:'Very Low',0:'Informational'}

def walk(obj: Any):
    if isinstance(obj, dict):
        yield obj
        for v in obj.values(): yield from walk(v)
    elif isinstance(obj, list):
        for v in obj: yield from walk(v)

def first(d, *keys):
    for k in keys:
        if k in d and d[k] not in (None, '', []): return d[k]
    return None

def findings(data):
    # Prefer common top-level arrays, then conservatively detect finding-like dicts.
    for k in ('findings','flaws','issues','results'):
        v = data.get(k) if isinstance(data, dict) else None
        if isinstance(v, list) and any(isinstance(x, dict) for x in v):
            return [x for x in v if isinstance(x, dict)]
    out=[]; seen=set()
    for d in walk(data):
        if not isinstance(d, dict): continue
        fid=first(d,'issue_id','finding_id','flaw_id','id')
        cwe=first(d,'cwe','cwe_id','cweid')
        path=first(d,'file','file_path','source_file','filename','sourcefile')
        if fid is not None and (cwe is not None or path is not None):
            key=(str(fid),str(path),str(cwe))
            if key not in seen: seen.add(key); out.append(d)
    return out

def norm_sev(v):
    if isinstance(v,(int,float)): return SEV.get(int(v),str(v))
    s=str(v or 'Unknown').strip(); low=s.lower()
    if low in ('5','very high','very_high','critical'): return 'Critical'
    if low in ('4','high'): return 'High'
    if low in ('3','medium'): return 'Medium'
    if low in ('2','low'): return 'Low'
    if low in ('1','very low','very_low'): return 'Very Low'
    if low in ('0','info','informational'): return 'Informational'
    return s

def clean_cwe(v):
    if isinstance(v, dict): v=first(v,'id','cwe_id','name')
    if v is None: return 'Unknown'
    s=str(v); m=re.search(r'(?:CWE[- ]?)?(\d+)',s,re.I)
    return 'CWE-'+m.group(1) if m else s

# Normalized aliases seen across Veracode REST/XML-derived exports and wrappers.
ALIASES = {
    'file': ('file','file_path','filepath','source_file','sourcefile','filename','file_name','relative_path','path'),
    'method': ('method','method_name','methodname','function','function_name','functionname','procedure','procedure_name','symbol','scope'),
    'line': ('line','line_number','linenumber','source_line','line_no','line_number_start','start_line'),
    'source': ('untrusted_source','source_name','source_type','taint_source','data_source','source'),
    'sink': ('risky_sink','sink_name','sink_type','taint_sink','data_sink','attack_vector','sink'),
    'module': ('module','module_name','moduleName','scanned_module'),
}

def deep_values(obj, aliases):
    """Yield non-empty values for exact normalized keys anywhere under one finding."""
    wanted={re.sub(r'[^a-z0-9]','',x.lower()) for x in aliases}
    for d in walk(obj):
        if not isinstance(d,dict): continue
        for k,v in d.items():
            nk=re.sub(r'[^a-z0-9]','',str(k).lower())
            if nk in wanted and v not in (None,'',[],{}):
                yield v

def scalar(v):
    if isinstance(v,dict):
        return first(v,'name','value','path','file','filename','method','function','type','id')
    if isinstance(v,list):
        for x in v:
            z=scalar(x)
            if z not in (None,''): return z
        return None
    return v

def deep_first(obj, kind):
    for v in deep_values(obj, ALIASES[kind]):
        z=scalar(v)
        if z not in (None,''): return z
    return None

def extract_callstack(f):
    """Keep compact reported path evidence when an export embeds call-stack/data-path rows."""
    rows=[]
    for d in walk(f):
        if not isinstance(d,dict): continue
        filev=first(d,*ALIASES['file']); meth=first(d,*ALIASES['method']); line=first(d,*ALIASES['line'])
        if filev or meth or line:
            row={'file':scalar(filev),'method':scalar(meth),'line':scalar(line)}
            if row not in rows: rows.append(row)
        if len(rows)>=100: break
    return rows

EXT_LANG = {
 '.java':'java','.kt':'kotlin','.kts':'kotlin','.scala':'scala','.groovy':'groovy',
 '.cs':'csharp','.vb':'vbnet','.fs':'fsharp','.fsx':'fsharp',
 '.js':'javascript','.jsx':'javascript','.mjs':'javascript','.cjs':'javascript',
 '.ts':'typescript','.tsx':'typescript','.vue':'vue','.svelte':'svelte',
 '.py':'python','.pyw':'python','.rb':'ruby','.php':'php','.phtml':'php',
 '.go':'go','.rs':'rust','.swift':'swift','.m':'objective-c','.mm':'objective-cpp',
 '.c':'c','.h':'c-cpp-header','.cc':'cpp','.cpp':'cpp','.cxx':'cpp','.hpp':'cpp',
 '.sql':'sql','.psql':'sql','.plsql':'plsql','.pls':'plsql','.pkb':'plsql','.pks':'plsql',
 '.cbl':'cobol','.cob':'cobol','.cpy':'cobol','.pl':'perl','.pm':'perl',
 '.sh':'shell','.bash':'shell','.ps1':'powershell','.psm1':'powershell',
 '.cls':'apex','.trigger':'apex','.page':'visualforce','.component':'visualforce',
 '.html':'html','.htm':'html','.xml':'xml','.jsp':'jsp','.jspx':'jsp','.asp':'asp','.aspx':'aspx',
 '.cfm':'coldfusion','.cfml':'coldfusion','.gohtml':'go-template','.dart':'dart','.ex':'elixir','.exs':'elixir',
 '.erl':'erlang','.hrl':'erlang','.lua':'lua','.r':'r','.R':'r','.sol':'solidity'
}

def detect_technology(path, rel=None):
    ext=path.suffix if path else Path(str(rel or '')).suffix
    lang=EXT_LANG.get(ext, EXT_LANG.get(ext.lower(), ext.lower().lstrip('.') or 'unknown'))
    low=str(rel or path or '').replace('\\','/').lower()
    # Technology/framework hints stay conservative; language remains universally usable.
    if lang=='apex': return ('apex','salesforce')
    if lang=='visualforce': return ('visualforce','salesforce')
    if lang in ('javascript','typescript') and any(x in low for x in ('/lwc/','/aura/','salesforce')): return (lang,'salesforce')
    return (lang,lang)

def resolve_path(repo: Path, raw):
    if not raw: return None
    raw=str(scalar(raw) or '').strip().strip('"\'')
    if not raw: return None
    p=Path(raw.replace('\\','/'))
    candidates=[repo/p]
    parts=p.parts
    for i in range(1,min(len(parts),8)):
        candidates.append(repo/Path(*parts[i:]))
    for c in candidates:
        try:
            if c.is_file(): return c.resolve()
        except OSError: pass
    # Packaging prefixes can be completely different. Suffix/basename fallback is bounded
    # to the referenced filename and accepted only when the match is unique.
    name=p.name
    if name:
        try:
            matches=[]
            for c in repo.rglob(name):
                if c.is_file():
                    matches.append(c)
                    if len(matches)>25: break
            if len(matches)==1: return matches[0].resolve()
            if len(matches)>1 and len(parts)>1:
                suffix='/'.join(parts[-min(4,len(parts)):]).lower()
                sm=[c for c in matches if c.as_posix().lower().endswith(suffix)]
                if len(sm)==1: return sm[0].resolve()
        except OSError: pass
    return None

def analyze_source(path: Path):
    try: text=path.read_text(encoding='utf-8',errors='replace')
    except Exception: return {'language':'unknown','symbols':[],'calls':[]}
    ext=path.suffix.lower(); lang=detect_technology(path, path.as_posix())[0]
    symbols=[]; calls=[]
    patterns=[]
    if lang=='java':
        patterns=[('class',r'\b(?:class|interface|enum|record)\s+([A-Za-z_$][\w$]*)'),('method',r'(?m)^\s*(?:public|protected|private|static|final|synchronized|abstract|native|default|\s)+[\w<>,.?\[\] ]+\s+([A-Za-z_$][\w$]*)\s*\([^;{}]*\)\s*(?:throws[^\{]+)?\{')]
    elif lang in ('typescript','javascript','kotlin','python'):
        patterns=[('function',r'(?m)^\s*(?:def|fun|function|async\s+function)\s+([A-Za-z_$][\w$]*)\s*\('),('class',r'\bclass\s+([A-Za-z_$][\w$]*)')]
    elif lang=='apex':
        patterns=[('class',r'\b(?:public|private|global|virtual|abstract|with\s+sharing|without\s+sharing|inherited\s+sharing|\s)*class\s+([A-Za-z_$][\w$]*)'),('method',r'(?m)^\s*(?:public|private|protected|global|static|virtual|override|webservice|testMethod|\s)+[A-Za-z_$][\w$<>,.\[\]? ]*\s+([A-Za-z_$][\w$]*)\s*\([^;{}]*\)\s*\{'),('trigger',r'\btrigger\s+([A-Za-z_$][\w$]*)\s+on\s+[A-Za-z_$][\w$]*')]
    elif lang=='visualforce':
        patterns=[('component',r'<(?:apex:page|apex:component)\b')]
    elif lang=='cobol':
        patterns=[('procedure',r'(?m)^\s{0,7}([A-Z0-9][A-Z0-9-]*)\.\s*$')]
    for typ,pat in patterns:
        for m in re.finditer(pat,text,re.I):
            line=text.count('\n',0,m.start())+1; symbols.append({'type':typ,'name':m.group(1),'line':line})
    # Calls are hints only; graph consumers must not treat them as proven data-flow.
    if lang in ('java','typescript','javascript','kotlin','apex'):
        names=[]
        for m in re.finditer(r'\b([A-Za-z_$][\w$]*)\s*\(',text):
            n=m.group(1)
            if n not in {'if','for','while','switch','catch','return','new','throw','super','this'}: names.append(n)
        calls=sorted(set(names))[:1000]
    return {'language':lang,'symbols':symbols[:2000],'calls':calls}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--repo-root',required=True); ap.add_argument('--results',required=True)
    ap.add_argument('--project',required=True); ap.add_argument('--scan-date',required=True); ap.add_argument('--output',required=True); ap.add_argument('--rules',required=False)
    args=ap.parse_args(); repo=Path(args.repo_root).resolve(); rp=Path(args.results).resolve(); out=Path(args.output).resolve(); out.mkdir(parents=True,exist_ok=True)
    data=json.loads(rp.read_text(encoding='utf-8-sig')); fs=findings(data)
    rules_path=Path(args.rules).resolve() if args.rules else Path(__file__).resolve().parents[2]/'config'/'remediation-rules.json'
    rulebook=json.loads(rules_path.read_text(encoding='utf-8-sig')) if rules_path.is_file() else {}
    nodes={}; edges=[]; paths=[]
    def node(nid,typ,**attrs): nodes.setdefault(nid,{'id':nid,'type':typ,**attrs}); return nid
    project=node('project:'+args.project,'Project',name=args.project)
    file_cache={}
    for i,f in enumerate(fs,1):
        fid=str(first(f,'issue_id','finding_id','flaw_id','id') or i)
        cwe=clean_cwe(first(f,'cwe','cwe_id','cweid')); sev=norm_sev(first(f,'severity','severity_name','severity_text','severity_id'))
        raw=deep_first(f,'file'); line=deep_first(f,'line')
        method=deep_first(f,'method')
        source=deep_first(f,'source'); sink=deep_first(f,'sink')
        reported_path=extract_callstack(f)
        fn=node('finding:'+fid,'Finding',finding_id=fid,severity=sev,line=line,raw_file=raw,method=method)
        cn=node('cwe:'+cwe,'CWE',name=cwe); edges += [{'from':fn,'to':cn,'type':'HAS_CWE'},{'from':project,'to':fn,'type':'HAS_FINDING'}]
        resolved=resolve_path(repo,raw)
        rel=None
        if resolved:
            try: rel=resolved.relative_to(repo).as_posix()
            except ValueError: rel=str(resolved)
            file_id=node('file:'+rel,'File',path=rel)
            edges.append({'from':fn,'to':file_id,'type':'AFFECTS'})
            if rel not in file_cache: file_cache[rel]=analyze_source(resolved)
            a=file_cache[rel]
            for s in a['symbols']:
                sid=node('symbol:'+rel+':'+s['type']+':'+s['name']+':'+str(s['line']),'Symbol',name=s['name'],symbol_type=s['type'],line=s['line'],file=rel)
                edges.append({'from':file_id,'to':sid,'type':'DEFINES'})
                if method and str(method)==s['name']: edges.append({'from':fn,'to':sid,'type':'AFFECTS_SYMBOL'})
        srcid=None; sinkid=None
        if source:
            srcid=node('source:'+str(source),'Source',name=str(source)); edges.append({'from':fn,'to':srcid,'type':'REPORTS_SOURCE'})
        if sink:
            sinkid=node('sink:'+str(sink),'Sink',name=str(sink)); edges.append({'from':fn,'to':sinkid,'type':'REPORTS_SINK'})
        language,technology=detect_technology(resolved, rel or raw)
        if rel and file_cache.get(rel,{}).get('language'): language=file_cache[rel]['language']
        explicit_rule=rulebook.get('rules',{}).get(cwe)
        rule_source='explicit' if explicit_rule else 'default_rule'
        remediation_rule=explicit_rule or rulebook.get('default_rule',{})
        tech_key={'java':'java_spring','kotlin':'java_spring','cobol':'cobol_db2','apex':'salesforce','visualforce':'salesforce','javascript':'salesforce' if technology=='salesforce' else 'angular_typescript','typescript':'salesforce' if technology=='salesforce' else 'angular_typescript','html':'angular_typescript'}.get(language)
        tech_rule=(rulebook.get('technology',{}).get(tech_key,{}).get(cwe) if tech_key else None)
        p={'finding_id':fid,'cwe':cwe,'severity':sev,
           'technology':technology,'language':language,
           'file':rel or scalar(raw),'file_path':rel or scalar(raw),'file_resolved':bool(resolved),
           'line':line,'method':method,'source':source,'sink':sink,
           'reported_path':reported_path,
           'evidence':{'file':'results.json' if raw else 'missing','method':'results.json' if method else 'missing','source':'results.json' if source else 'missing','sink':'results.json' if sink else 'missing','technology':'repository-extension' if (resolved or raw) else 'unknown'},
           'missing_evidence':[k for k,v in [('file_path',rel or scalar(raw)),('method',method),('source',source),('sink',sink)] if not v],
           'path_confidence':'reported-by-veracode' if (source or sink or reported_path) else 'context-only',
           'rule_source':rule_source,'rule_category':remediation_rule.get('category','Generic CWE') if isinstance(remediation_rule,dict) else 'Generic CWE','technology_rule':tech_rule,
           'remediation_gate':'ANALYZE' if ((rel or raw) and (explicit_rule or tech_rule or source or sink or method)) else 'REQUIRES_EVIDENCE'}
        paths.append(p)
    graph={'schema_version':'1.1','generated_at':datetime.now(timezone.utc).isoformat(),'scope':'focused-remediation-context-only','project':args.project,'scan_date':args.scan_date,'authoritative_results':str(rp),'nodes':sorted(nodes.values(),key=lambda x:x['id']),'edges':edges,'source_analysis':file_cache,'limitations':['No vulnerability discovery is performed.','Only files referenced by results.json are opened.','Source/sink relationships come from Veracode fields when present.','Static call-name extraction is contextual and is not proof of data flow.']}
    (out/'graph.json').write_text(json.dumps(graph,indent=2),encoding='utf-8')
    (out/'vulnerability-paths.json').write_text(json.dumps({'project':args.project,'scan_date':args.scan_date,'paths':paths},indent=2),encoding='utf-8')
    print('Knowledge graph generated:',out/'graph.json'); print('Findings:',len(fs),'Referenced source files analyzed:',len(file_cache))
if __name__=='__main__': main()
