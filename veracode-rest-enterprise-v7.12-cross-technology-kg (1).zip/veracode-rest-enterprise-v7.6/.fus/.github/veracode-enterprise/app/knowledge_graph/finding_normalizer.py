#!/usr/bin/env python3
"""Normalize Veracode findings for graph/path consumers.

Dependency-free and remediation-agent independent. Veracode finding id is the
primary identity. SHA-256 is a secondary correlation fingerprint only.
"""
import hashlib
import re
from pathlib import Path

SEV = {5:'Critical',4:'High',3:'Medium',2:'Low',1:'Very Low',0:'Informational'}

EXT_TECH = {
    '.java':'java', '.kt':'kotlin', '.kts':'kotlin', '.cs':'csharp',
    '.ts':'typescript', '.tsx':'typescript', '.js':'javascript', '.jsx':'javascript',
    '.py':'python', '.php':'php', '.rb':'ruby', '.go':'go', '.rs':'rust',
    '.c':'c', '.h':'c', '.cc':'cpp', '.cpp':'cpp', '.cxx':'cpp', '.hpp':'cpp',
    '.cbl':'cobol', '.cob':'cobol', '.cobol':'cobol', '.cpy':'cobol', '.copy':'cobol',
    '.pco':'cobol', '.sqb':'cobol', '.jcl':'jcl',
    '.cls':'apex', '.trigger':'apex', '.page':'visualforce', '.component':'visualforce',
    '.cmp':'aura', '.app':'aura', '.evt':'aura', '.design':'aura', '.auradoc':'aura',
    '.html':'html', '.htm':'html', '.css':'css', '.xml':'metadata', '.sql':'sql',
    '.swift':'swift', '.m':'objective-c', '.mm':'objective-cpp', '.scala':'scala',
    '.sc':'scala', '.groovy':'groovy', '.gradle':'groovy', '.dart':'dart',
    '.pl':'perl', '.pm':'perl', '.lua':'lua', '.sh':'shell', '.bash':'shell',
    '.ps1':'powershell', '.psm1':'powershell', '.r':'r', '.fs':'fsharp',
    '.fsx':'fsharp', '.vb':'visual_basic', '.vbs':'vbscript', '.asp':'asp',
    '.aspx':'aspnet', '.cshtml':'razor', '.razor':'razor', '.jsp':'jsp',
    '.jspx':'jsp', '.vue':'vue', '.svelte':'svelte', '.json':'json',
    '.yaml':'yaml', '.yml':'yaml', '.tf':'terraform', '.tfvars':'terraform',
    '.ex':'elixir', '.exs':'elixir', '.erl':'erlang', '.hrl':'erlang',
    '.hs':'haskell', '.lhs':'haskell', '.jl':'julia', '.sas':'sas',
    '.abap':'abap', '.pro':'progress_4gl', '.p':'progress_4gl',
    '.rpg':'rpg', '.rpgle':'rpg', '.sqlrpgle':'rpg', '.clle':'ibmi_cl',
    '.pli':'pli', '.pl1':'pli', '.bms':'bms', '.map':'bms',
    '.pc':'embedded_sql_c', '.ec':'embedded_sql_c', '.ecl':'embedded_sql_c' 
}

def first(d, *keys):
    if not isinstance(d, dict): return None
    for k in keys:
        if k in d and d[k] not in (None, '', []): return d[k]
    return None

def deep_first(value, *keys):
    """Breadth-first lookup for Veracode fields nested under issue/details/location/raw."""
    wanted = {str(k).lower() for k in keys}
    queue=[value]; seen=set()
    while queue:
        cur=queue.pop(0)
        oid=id(cur)
        if oid in seen: continue
        seen.add(oid)
        if isinstance(cur, dict):
            # Exact aliases first so caller preference is preserved.
            for k in keys:
                if k in cur and cur[k] not in (None, '', []): return cur[k]
            # Then tolerate casing differences from API versions.
            for k,v in cur.items():
                if str(k).lower() in wanted and v not in (None, '', []): return v
            queue.extend(cur.values())
        elif isinstance(cur, list): queue.extend(cur)
    return None

def norm_sev(v):
    if isinstance(v,(int,float)): return SEV.get(int(v),str(v))
    s=str(v or 'Unknown').strip(); low=s.lower()
    return {'5':'Critical','very high':'Critical','very_high':'Critical','critical':'Critical',
            '4':'High','high':'High','3':'Medium','medium':'Medium','2':'Low','low':'Low',
            '1':'Very Low','very low':'Very Low','very_low':'Very Low','0':'Informational',
            'info':'Informational','informational':'Informational'}.get(low,s)

def clean_cwe(v):
    if isinstance(v, dict): v=first(v,'id','cwe_id','cweid','name')
    if v is None: return 'Unknown'
    s=str(v); m=re.search(r'(?:CWE[- ]?)?(\d+)',s,re.I)
    return 'CWE-'+m.group(1) if m else s

def normalize_path(raw):
    if raw is None: return None
    s=str(raw).strip().replace('\\','/')
    while '//' in s: s=s.replace('//','/')
    while s.startswith('./'): s=s[2:]
    return s or None

def filename_from_path(raw):
    p=normalize_path(raw)
    return p.rsplit('/',1)[-1] if p else None

def normalize_technology(v):
    if isinstance(v, dict): v=first(v,'name','technology','language','type')
    if not v: return None
    s=str(v).strip().lower()
    aliases={'java/j2ee':'java','j2ee':'java','spring':'java','spring boot':'java',
             'c#':'csharp','.net':'csharp','dotnet':'csharp','js':'javascript','nodejs':'javascript',
             'node.js':'javascript','ts':'typescript','salesforce apex':'apex','salesforce':'apex',
             'visual force':'visualforce','salesforce apex':'apex','salesforce visualforce':'visualforce',
             'salesforce lightning':'salesforce_lwc','lightning web components':'salesforce_lwc','lwc':'salesforce_lwc',
             'aura':'aura','salesforce aura':'aura','cobol/db2':'cobol','ibm cobol':'cobol','enterprise cobol':'cobol'}
    return aliases.get(s,s.replace(' ','_'))

def technology_for(raw_path, explicit=None):
    tech=normalize_technology(explicit)
    if tech: return tech, 'veracode'
    p=normalize_path(raw_path)
    ext=Path(p).suffix.lower() if p else ''
    # Path context disambiguates shared web/XML extensions used by Salesforce.
    low=(p or '').lower().replace('\\','/')
    if ext in ('.js','.ts','.html','.css') and '/lwc/' in ('/'+low):
        return 'salesforce_lwc', 'path-context'
    if ext in ('.js','.html','.css','.cmp','.app','.evt','.design') and '/aura/' in ('/'+low):
        return 'aura', 'path-context'
    if ext == '.xml' and any(x in low for x in ('force-app/','salesforce/','/objects/','/permissionsets/','/profiles/','/classes/','/triggers/')):
        return 'salesforce_metadata', 'path-context'
    if ext in EXT_TECH: return EXT_TECH[ext], 'file-extension'
    return 'unknown', 'unresolved'

def correlation_fingerprint(project, cwe, file_path, method):
    # Secondary identity only. Never use this as the authoritative finding id.
    material='|'.join([str(project or '').strip().lower(), str(cwe or '').strip().upper(),
                       str(normalize_path(file_path) or '').lower(), str(method or '').strip()])
    return hashlib.sha256(material.encode('utf-8')).hexdigest()

def deep_scalar(value, *keys):
    """Like deep_first, but never returns dict/list containers as field values."""
    wanted={str(k).lower() for k in keys}; queue=[value]; seen=set()
    while queue:
        cur=queue.pop(0); oid=id(cur)
        if oid in seen: continue
        seen.add(oid)
        if isinstance(cur,dict):
            for k in keys:
                v=cur.get(k)
                if v not in (None,'',[]) and not isinstance(v,(dict,list)): return v
            for k,v in cur.items():
                if str(k).lower() in wanted and v not in (None,'',[]) and not isinstance(v,(dict,list)): return v
            queue.extend(cur.values())
        elif isinstance(cur,list): queue.extend(cur)
    return None

def source_file_block(f):
    files=f.get('files') if isinstance(f,dict) else None
    if isinstance(files,dict):
        sf=files.get('source_file') or files.get('sourceFile')
        if isinstance(sf,dict): return sf
    return None

def path_candidates(f):
    """Ordered, deduplicated candidate paths; do not treat nested objects as strings."""
    sf=source_file_block(f)
    values=[]
    # Preserve the old supported aliases; image_path is a fallback, not an override.
    for obj,aliases in (
        (f,('file_path','filePath','relative_path','relativePath','module_path','modulePath')),
        (sf,('file','upload_file','uploadFile','file_name','fileName','filename')),
        (f,('source_file','sourceFile','sourcefile','file','file_name','fileName','filename')),
        (f,('image_path','imagePath')),
    ):
        if obj is None: continue
        for key in aliases:
            v=deep_scalar(obj,key)
            if isinstance(v,str) and v.strip():
                p=normalize_path(v)
                if p and p not in values: values.append(p)
    # Include nested location variants without mistaking source_file containers for paths.
    for container in (f.get('location'), f.get('locations'), f.get('details')) if isinstance(f,dict) else ():
        if container is not None:
            for key in ('file_path','filePath','source_path','sourcePath','file','filename','image_path','imagePath'):
                v=deep_scalar(container,key)
                if isinstance(v,str) and v.strip():
                    q=normalize_path(v)
                    if q and q not in values: values.append(q)
    return values

def normalize_finding(f, project=None, fallback_id=None):
    fid=deep_first(f,'issue_id','issueId','finding_id','findingId','flaw_id','flawId','id','issueid','flawid')
    has_authoritative_id=fid is not None
    fid=str(fid if fid is not None else fallback_id)
    sf=source_file_block(f)
    # Veracode Pipeline Scan commonly reports image_path plus files.source_file.file/upload_file.
    # Never stringify a source_file object into a path.
    candidates=path_candidates(f)
    raw=candidates[0] if candidates else None
    filename=filename_from_path(raw)
    method=(deep_scalar(sf,'qualified_function_name','qualifiedFunctionName','function_name','functionName','method','procedure','scope') if sf else None) or deep_scalar(f,'qualified_function_name','qualifiedFunctionName','function_name','functionName','method','procedure','scope')
    cwe=clean_cwe(deep_first(f,'cwe','cwe_id','cweId','cweid'))
    explicit_tech=deep_first(f,'technology','language','programming_language','programmingLanguage','platform','framework')
    tech,tech_source=technology_for(raw,explicit_tech)
    line=(deep_scalar(sf,'line','line_number','lineNumber','source_line','sourceLine','line_no') if sf else None) or deep_scalar(f,'line','line_number','lineNumber','source_line','sourceLine','line_no')
    # These are populated only when Veracode actually reports data-flow endpoints.
    reported_source=deep_first(f,'untrusted_source','untrustedSource','taint_source','taintSource','source_name','sourceName')
    sink=deep_first(f,'risky_sink','riskySink','taint_sink','taintSink','sink_name','sinkName')
    title=deep_scalar(f,'title','issue_type','issueType','name','category')
    description=deep_scalar(f,'display_text','displayText','description','issue_details','issueDetails','details')
    return {
        'finding_id':fid,
        'identity_source':'veracode-finding-id' if has_authoritative_id else 'generated-fallback',
        'fingerprint':correlation_fingerprint(project,cwe,raw,method),
        'fingerprint_role':'secondary-correlation-only',
        'cwe':cwe,
        'severity':norm_sev(deep_first(f,'severity','severity_name','severityName','severity_text','severityText','severity_id','severityId')),
        'raw_file':raw,
        'path_candidates':candidates,
        'filename':str(filename) if filename else None,
        'file_path':raw,
        'line':line,
        'method':method,
        'source':reported_source,
        'source_system':'Veracode',
        'sink':sink,
        'technology':tech,
        'technology_source':tech_source,
        'title':title,
        'description':description,
        'issue_type':deep_scalar(f,'issue_type','issueType'),
        'issue_type_id':deep_scalar(f,'issue_type_id','issueTypeId'),
        'image_path':deep_scalar(f,'image_path','imagePath'),
        'upload_file':(deep_scalar(sf,'upload_file','uploadFile') if sf else None),
        'qualified_function_name':(deep_scalar(sf,'qualified_function_name','qualifiedFunctionName') if sf else None),
        'function_prototype':(deep_scalar(sf,'function_prototype','functionPrototype') if sf else None),
        'scope':(deep_scalar(sf,'scope') if sf else None),
        'exploit_level':deep_scalar(f,'exploit_level','exploitLevel'),
        'qob':deep_scalar(f,'qob'),
        'metadata_status':'complete' if raw else 'veracode-location-missing'
    }
