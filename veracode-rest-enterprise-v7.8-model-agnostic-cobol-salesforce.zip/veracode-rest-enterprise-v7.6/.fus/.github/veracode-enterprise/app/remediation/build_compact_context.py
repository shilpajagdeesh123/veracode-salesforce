#!/usr/bin/env python3
from __future__ import print_function
import argparse, json, os
from pathlib import Path

def load(p):
    return json.loads(Path(p).read_text(encoding='utf-8-sig'))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--selected',required=True); ap.add_argument('--paths',required=True); ap.add_argument('--clusters',required=True); ap.add_argument('--output',required=True)
    a=ap.parse_args(); sel=load(a.selected); vp=load(a.paths); cl=load(a.clusters)
    selected=sel.get('findings',[]); pmap={str(x.get('finding_id')):x for x in vp.get('paths',[])}
    clusters=cl.get('clusters',[]) if isinstance(cl,dict) else []
    compact=[]
    for idx,c in enumerate(clusters,1):
        ids=[str(x) for x in c.get('finding_ids',c.get('findings',[]))]
        rows=[]
        for fid in ids:
            base=next((x for x in selected if str(x.get('finding_id'))==fid),{})
            path=pmap.get(fid,{})
            rows.append({'finding_id':fid,'cwe':base.get('cwe') or path.get('cwe'),'severity':base.get('severity'),'filename':path.get('filename'),'file_path':path.get('file_path') or base.get('file') or path.get('file'),'file':path.get('file_path') or base.get('file') or path.get('file'),'source_system':path.get('source_system') or 'Veracode','technology_source':path.get('technology_source'),'fingerprint':path.get('fingerprint'),'line':base.get('line') or path.get('line'),'technology':path.get('technology'),'source':path.get('source'),'sink':path.get('sink'),'path':path.get('path'),'confidence':path.get('confidence')})
        compact.append({'cluster_id':c.get('cluster_id') or c.get('id') or ('cluster-%03d'%idx),'cwe':c.get('cwe'),'technology':c.get('technology'),'root_cause':c.get('root_cause'),'strategy':c.get('strategy'),'finding_count':len(rows),'findings':rows})
    if not compact:
        for r in selected:
            fid=str(r.get('finding_id')); p=pmap.get(fid,{})
            compact.append({'cluster_id':'finding-'+fid,'cwe':r.get('cwe'),'technology':p.get('technology'),'finding_count':1,'findings':[{'finding_id':fid,'cwe':r.get('cwe'),'severity':r.get('severity'),'filename':p.get('filename'),'file_path':p.get('file_path') or r.get('file'),'file':p.get('file_path') or r.get('file'),'source_system':p.get('source_system') or 'Veracode','technology_source':p.get('technology_source'),'fingerprint':p.get('fingerprint'),'line':r.get('line'),'source':p.get('source'),'sink':p.get('sink'),'path':p.get('path'),'confidence':p.get('confidence')}]})
    out={'schema_version':'7.7','purpose':'compact model handoff; do not reload full results.json unless evidence is missing','project':sel.get('project'),'scan_date':sel.get('scan_date'),'selected_count':sel.get('selected_count',len(selected)),'cluster_count':len(compact),'clusters':compact,'execution_rules':['Process by cluster, not finding-by-finding.','Read each affected source file once per run and cache it.','Start with affected method plus narrow surrounding context; expand only when evidence requires it.','Do not load full graph.json into model context.','Do not reload results.json into model context.','Produce one consolidated patch per physical source file.']}
    op=Path(a.output); op.parent.mkdir(parents=True,exist_ok=True); op.write_text(json.dumps(out,indent=2),encoding='utf-8'); print('COMPACT_CONTEXT=GENERATED'); print('COMPACT_CLUSTERS='+str(len(compact))); print('COMPACT_CONTEXT_FILE='+str(op))
if __name__=='__main__': main()
