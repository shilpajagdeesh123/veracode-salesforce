#!/usr/bin/env python3
"""Normalize Veracode findings for graph/path consumers.

Dependency-free and remediation-agent independent. Veracode finding id is the
primary identity. SHA-256 is a secondary correlation fingerprint only.
"""
import hashlib
import re
from pathlib import Path

SEV = {5:'Critical',4:'High',3:'Medium',2:'Low',1:'Very Low',0:'Informational'}

EXT_TECH = {
    '.java':'java', '.kt':'kotlin', '.kts':'kotlin', '.cs':'csharp',
    '.ts':'typescript', '.tsx':'typescript', '.js':'javascript', '.jsx':'javascript',
    '.py':'python', '.php':'php', '.rb':'ruby', '.go':'go', '.rs':'rust',
    '.c':'c', '.h':'c', '.cc':'cpp', '.cpp':'cpp', '.cxx':'cpp', '.hpp':'cpp',
    '.cbl':'cobol', '.cob':'cobol', '.cobol':'cobol', '.cpy':'cobol', '.copy':'cobol',
    '.pco':'cobol', '.sqb':'cobol', '.jcl':'jcl',
    '.cls':'apex', '.trigger':'apex', '.page':'visualforce', '.component':'visualforce',
    '.cmp':'aura', '.app':'aura', '.evt':'aura', '.design':'aura', '.auradoc':'aura',
    '.html':'html', '.htm':'html', '.css':'css', '.xml':'metadata', '.sql':'sql'
}

def first(d, *keys):
    if not isinstance(d, dict): return None
    for k in keys:
        if k in d and d[k] not in (None, '', []): return d[k]
    return None

def norm_sev(v):
    if isinstance(v,(int,float)): return SEV.get(int(v),str(v))
    s=str(v or 'Unknown').strip(); low=s.lower()
    return {'5':'Critical','very high':'Critical','very_high':'Critical','critical':'Critical',
            '4':'High','high':'High','3':'Medium','medium':'Medium','2':'Low','low':'Low',
            '1':'Very Low','very low':'Very Low','very_low':'Very Low','0':'Informational',
            'info':'Informational','informational':'Informational'}.get(low,s)

def clean_cwe(v):
    if isinstance(v, dict): v=first(v,'id','cwe_id','cweid','name')
    if v is None: return 'Unknown'
    s=str(v); m=re.search(r'(?:CWE[- ]?)?(\d+)',s,re.I)
    return 'CWE-'+m.group(1) if m else s

def normalize_path(raw):
    if raw is None: return None
    s=str(raw).strip().replace('\\','/')
    while '//' in s: s=s.replace('//','/')
    while s.startswith('./'): s=s[2:]
    return s or None

def filename_from_path(raw):
    p=normalize_path(raw)
    return p.rsplit('/',1)[-1] if p else None

def normalize_technology(v):
    if isinstance(v, dict): v=first(v,'name','technology','language','type')
    if not v: return None
    s=str(v).strip().lower()
    aliases={'java/j2ee':'java','j2ee':'java','spring':'java','spring boot':'java',
             'c#':'csharp','.net':'csharp','dotnet':'csharp','js':'javascript','nodejs':'javascript',
             'node.js':'javascript','ts':'typescript','salesforce apex':'apex','salesforce':'apex',
             'visual force':'visualforce','salesforce apex':'apex','salesforce visualforce':'visualforce',
             'salesforce lightning':'salesforce_lwc','lightning web components':'salesforce_lwc','lwc':'salesforce_lwc',
             'aura':'aura','salesforce aura':'aura','cobol/db2':'cobol','ibm cobol':'cobol','enterprise cobol':'cobol'}
    return aliases.get(s,s.replace(' ','_'))

def technology_for(raw_path, explicit=None):
    tech=normalize_technology(explicit)
    if tech: return tech, 'veracode'
    p=normalize_path(raw_path)
    ext=Path(p).suffix.lower() if p else ''
    # Path context disambiguates shared web/XML extensions used by Salesforce.
    low=(p or '').lower().replace('\\','/')
    if ext in ('.js','.html','.css') and any(x in low for x in ('/lwc/','/aura/','force-app/','salesforce/')):
        return 'salesforce_lwc' if '/lwc/' in ('/'+low) else 'aura', 'path-context'
    if ext == '.xml' and any(x in low for x in ('force-app/','salesforce/','/objects/','/permissionsets/','/profiles/','/classes/','/triggers/')):
        return 'salesforce_metadata', 'path-context'
    if ext in EXT_TECH: return EXT_TECH[ext], 'file-extension'
    return 'unknown', 'unresolved'

def correlation_fingerprint(project, cwe, file_path, method):
    # Secondary identity only. Never use this as the authoritative finding id.
    material='|'.join([str(project or '').strip().lower(), str(cwe or '').strip().upper(),
                       str(normalize_path(file_path) or '').lower(), str(method or '').strip()])
    return hashlib.sha256(material.encode('utf-8')).hexdigest()

def normalize_finding(f, project=None, fallback_id=None):
    fid=first(f,'issue_id','finding_id','flaw_id','id','issueid','flawid')
    fid=str(fid if fid is not None else fallback_id)
    raw=first(f,'file_path','source_file','sourcefile','file','filename','module_path','relative_path')
    raw=normalize_path(raw)
    filename=first(f,'filename','file_name','source_filename') or filename_from_path(raw)
    method=first(f,'method','method_name','function','procedure','function_name','scope')
    cwe=clean_cwe(first(f,'cwe','cwe_id','cweid','cweId'))
    explicit_tech=first(f,'technology','language','programming_language','platform','framework')
    tech,tech_source=technology_for(raw,explicit_tech)
    reported_source=first(f,'source','untrusted_source','source_name','taint_source')
    sink=first(f,'sink','risky_sink','sink_name','taint_sink')
    return {
        'finding_id':fid,
        'identity_source':'veracode-finding-id' if first(f,'issue_id','finding_id','flaw_id','id','issueid','flawid') is not None else 'generated-fallback',
        'fingerprint':correlation_fingerprint(project,cwe,raw,method),
        'fingerprint_role':'secondary-correlation-only',
        'cwe':cwe,
        'severity':norm_sev(first(f,'severity','severity_name','severity_text','severity_id')),
        'raw_file':raw,
        'filename':str(filename) if filename else None,
        'file_path':raw,
        'line':first(f,'line','line_number','source_line','line_no','lineNumber'),
        'method':method,
        'source':reported_source,
        'source_system':'Veracode',
        'sink':sink,
        'technology':tech,
        'technology_source':tech_source
    }
