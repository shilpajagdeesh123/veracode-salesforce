# Focused remediation knowledge graph

`graph_builder.py` builds a local JSON graph from the selected Veracode `results.json` and only the source files referenced by those findings. It does not scan for new vulnerabilities and requires no external graph database or Python dependency.

Outputs belong under repository root `.github/output/knowledge-graph/<project>/<scan-date>/` and never under `.fus/output`.

## v7.7 normalized finding contract

The graph layer is independent of the remediation agent. `finding_normalizer.py`
normalizes Veracode finding identity and metadata before graph/path generation.
`finding_id` is authoritative. SHA-256 `fingerprint` is secondary correlation only
and is not required to locate or update a finding.

Each vulnerability path now carries `filename`, `file_path`, `source_system`,
reported `source`, `technology`, `technology_source`, and `fingerprint`. Technology
prefers explicit Veracode metadata and falls back deterministically to file extension.

## v7.8 COBOL and Salesforce resolution
COBOL/mainframe includes CBL/COB/COBOL, copybooks (CPY/COPY), embedded SQL variants (PCO/SQB), and JCL context. Salesforce includes Apex classes/triggers, Visualforce, Aura bundle files, LWC JS/HTML/CSS, and metadata XML. Shared extensions are classified as Salesforce only when Veracode metadata or repository path context supports it. Unknown file types are retained as `technology=unknown`; graph generation never depends on an LLM guessing a language.
