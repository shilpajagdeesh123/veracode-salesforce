#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,subprocess,sys,re
from pathlib import Path
from datetime import datetime,timezone
SEV={5:'Critical',4:'High',3:'Medium',2:'Low',1:'Very Low',0:'Informational'}
def walk(o):
    if isinstance(o,dict):
        yield o
        for v in o.values(): yield from walk(v)
    elif isinstance(o,list):
        for v in o: yield from walk(v)
def first(d,*ks):
    for k in ks:
        if k in d and d[k] not in (None,'',[]): return d[k]
def get_findings(data):
    for k in ('findings','flaws','issues','results'):
        v=data.get(k) if isinstance(data,dict) else None
        if isinstance(v,list) and any(isinstance(x,dict) for x in v): return [x for x in v if isinstance(x,dict)]
    out=[]; seen=set()
    for d in walk(data):
        if not isinstance(d,dict): continue
        fid=first(d,'issue_id','finding_id','flaw_id','id'); c=first(d,'cwe','cwe_id','cweid'); p=first(d,'file','file_path','source_file','filename','sourcefile')
        if fid is not None and (c is not None or p is not None):
            key=(str(fid),str(p),str(c))
            if key not in seen: seen.add(key); out.append(d)
    return out
def sev(v):
    if isinstance(v,(int,float)): return SEV.get(int(v),str(v))
    s=str(v or 'Unknown').strip(); return {'5':'Critical','very high':'Critical','very_high':'Critical','critical':'Critical','4':'High','high':'High','3':'Medium','medium':'Medium','2':'Low','low':'Low','1':'Very Low','very low':'Very Low','very_low':'Very Low','0':'Informational','info':'Informational','informational':'Informational'}.get(s.lower(),s)
def cwe(v):
    if isinstance(v,dict): v=first(v,'id','cwe_id','name')
    m=re.search(r'(?:CWE[- ]?)?(\d+)',str(v or ''),re.I); return 'CWE-'+m.group(1) if m else str(v or 'Unknown')
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--repo-root',required=True); ap.add_argument('--results',required=True); ap.add_argument('--project',required=True); ap.add_argument('--scan-date',required=True); ap.add_argument('--include',choices=['high','medium','low','medium-low'],default='high'); a=ap.parse_args()
    repo=Path(a.repo_root).resolve(); results=Path(a.results).resolve(); home=Path(__file__).resolve().parents[2]
    kg=repo/'.github/output/knowledge-graph'/a.project/a.scan_date; rem=repo/'.github/output/remediation/veracode'/a.project/a.scan_date; kg.mkdir(parents=True,exist_ok=True); rem.mkdir(parents=True,exist_ok=True)
    fs=get_findings(json.loads(results.read_text(encoding='utf-8-sig'))); allowed={'Critical','High'}
    if a.include in ('medium','medium-low'): allowed.add('Medium')
    if a.include in ('low','medium-low'): allowed.add('Low')
    rows=[]
    for i,f in enumerate(fs,1):
        s=sev(first(f,'severity','severity_name','severity_text','severity_id'))
        if s in allowed: rows.append({'finding_id':str(first(f,'issue_id','finding_id','flaw_id','id') or i),'cwe':cwe(first(f,'cwe','cwe_id','cweid')),'severity':s,'file':first(f,'file','file_path','source_file','filename','sourcefile'),'line':first(f,'line','line_number','source_line','line_no'),'status':'PENDING_GRAPH_ANALYSIS'})
    cmd=[sys.executable,str(home/'app/knowledge_graph/graph_builder.py'),'--repo-root',str(repo),'--results',str(results),'--project',a.project,'--scan-date',a.scan_date,'--output',str(kg),'--rules',str(home/'config/remediation-rules.json')]
    cp=subprocess.run(cmd,text=True,capture_output=True)
    if cp.returncode: print(cp.stdout); print(cp.stderr,file=sys.stderr); raise SystemExit('ERROR: mandatory knowledge graph generation failed')
    gp=kg/'graph.json'; vp=kg/'vulnerability-paths.json'
    if not gp.is_file() or not vp.is_file(): raise SystemExit('ERROR: mandatory knowledge graph artifacts missing')
    paths=json.loads(vp.read_text(encoding='utf-8')).get('paths',[]); ids={str(x.get('finding_id')) for x in paths}; missing=[r['finding_id'] for r in rows if r['finding_id'] not in ids]
    if missing: raise SystemExit('ERROR: selected findings missing from graph: '+','.join(missing))
    manifest={'schema_version':'7.3','generated_at':datetime.now(timezone.utc).isoformat(),'project':a.project,'scan_date':a.scan_date,'results_json':str(results),'knowledge_graph':{'status':'GENERATED','graph_json':str(gp),'vulnerability_paths_json':str(vp),'graph_findings':len(paths)},'selected_count':len(rows),'processed_count':0,'source_modified_by_veracode_r':False,'findings':rows}
    (rem/'selected-scan.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    lines=['# Veracode Remediation Report','',f'- Project: {a.project}',f'- Scan date: {a.scan_date}',f'- Results: `{results}`','- GRAPH_STATUS: GENERATED',f'- GRAPH_FINDINGS: {len(paths)}',f'- SELECTED_FINDINGS: {len(rows)}','- PROCESSED_FINDINGS: 0','- SOURCE_MODIFIED_BY_VERACODE_R: NO','','Every selected finding must receive one terminal status before completion.']
    (rem/'remediation-report.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('GRAPH_STATUS=GENERATED'); print('GRAPH_FINDINGS='+str(len(paths))); print('SELECTED_FINDINGS='+str(len(rows))); print('REMEDIATION_OUTPUT='+str(rem))
if __name__=='__main__': main()
