#!/usr/bin/env sh
set -eu
TOOL_HOME=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
for PY in "$TOOL_HOME/runtime/python/bin/python3" "$TOOL_HOME/runtime/python/python3"; do
  if [ -x "$PY" ]; then exec "$PY" "$TOOL_HOME/app/remediation/remediation_preflight.py" "$@"; fi
done
echo "ERROR: Package-owned Python runtime is missing. Run setup-runtime.sh first." >&2
exit 2
