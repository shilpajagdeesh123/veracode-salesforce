# Knowledge-Graph Remediation

Veracode-R uses a focused local JSON knowledge graph. No Neo4j is required. Critical/Very High/High findings are automatically selected for analysis, but a patch is generated only when evidence supports a safe remediation.

Supported technology-aware contexts include Java/Spring, COBOL/DB2, Salesforce Apex/Triggers/Visualforce/LWC, and Angular/TypeScript. The graph records finding, CWE, file/symbol, reported source/sink and directly relevant code context.

Outputs:
- `.github/output/knowledge-graph/<project>/<scan-date>/graph.json`
- `.github/output/knowledge-graph/<project>/<scan-date>/vulnerability-paths.json`
- `.github/output/remediation/veracode/<project>/<scan-date>/`

Salesforce rules preserve sharing, CRUD/FLS, execution-mode, authorization, governor-limit and business semantics. SQL/SOQL injection remediation prefers binding/parameterization and uses allowlists only for syntax elements that cannot be bound.
