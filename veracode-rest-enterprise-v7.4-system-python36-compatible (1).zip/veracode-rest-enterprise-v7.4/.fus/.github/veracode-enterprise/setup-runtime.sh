#!/usr/bin/env sh
set -eu
if command -v python3 >/dev/null 2>&1; then PYTHON_EXE=python3
elif command -v python >/dev/null 2>&1; then PYTHON_EXE=python
else echo "ERROR: Python is not available on PATH." >&2; exit 2; fi
"$PYTHON_EXE" -c 'import sys; sys.exit(0 if sys.version_info >= (3,6) else 1)' || { echo "ERROR: Python 3.6 or newer is required." >&2; exit 2; }
echo "System Python is ready:"
"$PYTHON_EXE" --version
