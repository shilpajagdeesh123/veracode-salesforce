# Runtime security - v7.4

The Veracode package does not bundle, download, or bootstrap Python.
It uses the installed Python interpreter available on PATH and requires Python 3.6 or newer.
Keep the machine-managed Python installation patched according to your organization's runtime policy.
Veracode credentials remain local to the configured secrets file and must not be committed.
