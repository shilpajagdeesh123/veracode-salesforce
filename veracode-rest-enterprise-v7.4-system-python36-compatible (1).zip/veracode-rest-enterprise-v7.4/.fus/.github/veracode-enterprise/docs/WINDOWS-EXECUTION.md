# Windows execution - v7.4

## Requirement
Python 3.6 or newer must already be installed and available as `python.exe` on PATH.
The package does not download or use a private Python runtime.

## Scan
Run `run-Veracode.bat` from `.fus/.github/veracode-enterprise`.
The launcher verifies the installed Python version, configures/checks Veracode credentials, and starts the scan workflow.

## Remediation preflight
Run `run-remediation-preflight.bat` with the required arguments, or invoke it through the Veracode remediation agent/SKILL.
It uses the same system Python and creates the mandatory knowledge-graph artifacts before remediation.
