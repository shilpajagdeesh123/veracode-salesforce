#!/usr/bin/env python3
import argparse,subprocess
from pathlib import Path
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--original',required=True); ap.add_argument('--remediated',required=True); ap.add_argument('--output',required=True); a=ap.parse_args()
    original=Path(a.original).resolve(); remediated=Path(a.remediated).resolve(); out=Path(a.output).resolve(); out.parent.mkdir(parents=True,exist_ok=True)
    if not original.is_file() or not remediated.is_file(): raise SystemExit('ERROR: original/remediated file missing')
    cp=subprocess.run(['git','diff','--no-index','--binary','--no-ext-diff','--',str(original),str(remediated)], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if cp.returncode not in (0,1): raise SystemExit('ERROR: git diff --no-index failed: '+cp.stderr.decode(errors='replace'))
    if not cp.stdout: raise SystemExit('ERROR: no differences; patch not generated')
    out.write_bytes(cp.stdout); print('PATCH_GENERATED='+str(out))
if __name__=='__main__': main()
