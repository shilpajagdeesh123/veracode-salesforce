@echo off
setlocal EnableExtensions
echo ==========================================================
echo  Veracode System Python Check
echo ==========================================================
where python.exe >nul 2>&1
if errorlevel 1 (echo ERROR: Python is not available on PATH.& exit /b 2)
python.exe -c "import sys; sys.exit(0 if sys.version_info >= (3,6) else 1)"
if errorlevel 1 (echo ERROR: Python 3.6 or newer is required.& python.exe --version& exit /b 2)
echo System Python is ready:
python.exe --version
python.exe -c "import sys; print('Python executable:', sys.executable)"
exit /b 0
