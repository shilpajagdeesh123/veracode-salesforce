@echo off
setlocal EnableExtensions
set "TOOL_HOME=%~dp0"
echo Checking installed system Python...
where python.exe >nul 2>&1
if errorlevel 1 (echo ERROR: Python is not available on PATH.& exit /b 2)
python.exe -c "import sys; sys.exit(0 if sys.version_info >= (3,6) else 1)" >nul 2>&1
if errorlevel 1 (echo ERROR: Python 3.6 or newer is required.& exit /b 2)
python.exe "%TOOL_HOME%app\configure_credentials.py" "%TOOL_HOME%"
exit /b %ERRORLEVEL%
