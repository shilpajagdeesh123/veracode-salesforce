@echo off
setlocal EnableExtensions
for %%I in ("%~dp0.") do set "TOOL_HOME=%%~fI"

echo ==========================================================
echo  Veracode Enterprise Scan Launcher - System Python
echo ==========================================================
echo.
echo Step 1: Checking installed Python...
where python.exe >nul 2>&1
if errorlevel 1 (
  echo ERROR: Python is not available on PATH.
  echo Install/enable Python 3.6 or newer and rerun.
  exit /b 2
)
set "PYTHON_EXE=python.exe"
"%PYTHON_EXE%" -c "import sys; sys.exit(0 if sys.version_info >= (3,6) else 1)" >nul 2>&1
if errorlevel 1 (
  echo ERROR: Python 3.6 or newer is required.
  "%PYTHON_EXE%" --version
  exit /b 2
)
echo Python runtime selected from PATH:
"%PYTHON_EXE%" --version
"%PYTHON_EXE%" -c "import sys; print('Python executable:', sys.executable)"

echo.
echo Step 2: Checking Veracode HMAC credentials...
"%PYTHON_EXE%" "%TOOL_HOME%\app\configure_credentials.py" "%TOOL_HOME%"
if errorlevel 1 exit /b 3
if not exist "%TOOL_HOME%\config\scanner.json" (echo ERROR: scanner.json not found.& exit /b 4)

echo.
echo Step 3: Starting Veracode scan workflow...
"%PYTHON_EXE%" "%TOOL_HOME%\app\veracode_precommit.py" --tool-home "%TOOL_HOME%"
exit /b %ERRORLEVEL%
