---
name: veracode-remediation
description: Select a project/module from .github/output/veracode, automatically remediate Critical/Very High and High findings from its latest results.json, ask before including Medium or Low findings, and generate one consolidated patch per affected source file.
---

# Veracode Remediation Skill

## 1. Source of truth

The sole authoritative vulnerability input is a raw Pipeline Scan file named
`results.json` under `.github/output/veracode`.

Do not substitute CSV files, `veracode-findings.json`, manually typed summaries,
or findings from another scan when `results.json` exists.

Do not run a new vulnerability discovery scan. The remediation scope is strictly
limited to findings already present in the selected `results.json`.

## 2. Discover valid projects/modules

Inspect immediate child directories of:

`.github/output/veracode/`

A valid project/module contains at least one `results.json` in either layout:

```text
.github/output/veracode/<project>/<YYYY-MM-DD>/results.json
.github/output/veracode/<project>/<YYYY-MM-DD>/<HHMMSS>/results.json
```

Rules:

- `<project>` is always the directory immediately below `.github/output/veracode`.
- Ignore folders that contain no supported `results.json`.

## 3. Select the project/module

- Use a valid project/module explicitly named by the user.
- If exactly one valid project/module exists, select it automatically and state it.
- If two or more valid projects/modules exist, show a numbered list and ask exactly:

  `Select the project/module to remediate by number or name:`

Wait for the selection before changing source files.

Do not ask the user to select a scan date.

## 4. Select the latest scan automatically

For the selected project, inspect the project layout and choose the
newest scan by:

1. newest valid `YYYY-MM-DD` date directory;
2. newest timestamp/run subdirectory on that date;
3. newest `results.json` modification time when still tied.

Prefer a sibling `scan-status.json` showing a successful/completed scan. Skip any
scan folder without `results.json`.

State the exact repository-relative selected `results.json` path before editing.
Do not combine findings from different scans.


## 5. Severity selection policy

Normalize severity before selecting remediation scope. Use the severity text and
numeric rank available in `results.json`. Treat all of the following as the
highest severity group:

- `Critical`;
- `Very High`;
- numeric severity `5`;
- equivalent highest-severity labels returned by Veracode.

Default remediation scope:

- automatically include every Critical/Very High finding;
- automatically include every High finding;
- do not require confirmation for Critical/Very High or High findings.

Optional remediation scope:

- Medium findings require explicit user approval;
- Low and Very Low findings require explicit user approval;
- Informational findings are excluded unless the user explicitly names them in
  the original request.

After parsing the selected `results.json`, count findings by normalized severity.
When at least one Medium or Low/Very Low finding exists, ask exactly once:

`Critical and High findings will be remediated automatically. Include additional findings? [1] No [2] Medium only [3] Low only [4] Medium and Low:`

Interpret the answer as follows:

1. `No` — remediate only Critical/Very High and High.
2. `Medium only` — also include Medium.
3. `Low only` — also include Low and Very Low.
4. `Medium and Low` — include Medium, Low, and Very Low.

Also accept equivalent natural-language answers. If the response is unclear, ask
again and do not edit source files. If no Medium or Low/Very Low findings exist,
do not ask this question.

Record the severity counts, default-selected findings, user choice, included
finding IDs, and excluded finding IDs in `selected-scan.json` and
`remediation-report.md`. Excluded findings must not be marked remediated or added
to patch metadata.

## 6. Fast parsing and grouping

Parse `results.json` exactly once whenever possible.

For each finding, capture every available field, including:

- finding/flaw/issue ID;
- CWE;
- severity;
- title/category;
- module;
- source file and line;
- method/function/procedure;
- untrusted source;
- risky sink;
- description and remediation guidance;
- data path/call stack;
- status.

Never fabricate missing fields. Use `Not present in results.json` where needed.

After applying the severity selection policy, normalize the repository-relative
source path and build this logical map from selected findings only before opening
source files:

```text
<source-file-1> -> [finding A, finding B, finding C]
<source-file-2> -> [finding D]
```

Performance requirements:

- Do not search the entire repository separately for every finding.
- Do not repeatedly reopen the same source file.
- Open each affected source file once whenever possible.
- Process all findings mapped to that file in one remediation pass.
- Inspect a directly related caller, copybook, include, service, or configuration
  only when it is necessary to understand the reported flow.
- Never scan unrelated files to look for additional vulnerabilities.

## 7. Focused knowledge graph and remediation gate (mandatory)

Before deciding a fix or generating any patch, build or refresh a focused repository-local knowledge graph for the selected scan. This graph is a mandatory analysis gate for every Critical/Very High and High finding. It is context for remediation; it is not a new vulnerability scan and must never expand scope beyond the selected `results.json`.

Use the package-owned builder:

```text
.fus/.github/veracode-enterprise/app/knowledge_graph/graph_builder.py
```

Use the package-owned Python runtime when available. Never require Neo4j, a network graph service, or system-wide Python. Persist only local JSON artifacts:

```text
.github/output/knowledge-graph/<project-or-module>/<scan-date>/graph.json
.github/output/knowledge-graph/<project-or-module>/<scan-date>/vulnerability-paths.json
```

For each selected finding establish, where evidence permits:

`Finding -> CWE -> File -> Symbol -> Source -> Transformations/Call Context -> Security Control -> Sink -> Technology-specific Remediation Strategy`

Evidence priority is: Veracode-reported source/sink/call-stack/data path, then directly inspected affected source, then narrowly related caller/callee context. Syntax-derived relationships are contextual hints only and must never be represented as proven taint flow.

Before patch generation determine:

1. technology/language and framework;
2. affected source file and symbol;
3. CWE and reported source/sink;
4. minimum relevant source-to-sink path;
5. existing validation, encoding, authorization, sharing, CRUD/FLS, parameterization, or other security controls;
6. root cause;
7. smallest safe remediation point;
8. whether the proposed correction actually breaks or safely controls the vulnerable path without weakening existing controls.

Read technology-aware guidance from:

```text
.fus/.github/veracode-enterprise/config/remediation-rules.json
```

### Confidence gate

- `HIGH`: CWE, affected symbol, relevant source/sink path and safe correction are sufficiently supported -> patch may be generated.
- `MEDIUM`: sink/root cause is supported but directly related context is missing -> inspect only the required caller/callee/include/copybook/component and re-evaluate.
- `LOW`: safe correction requires assumptions or source/sink cannot be established -> set `REQUIRES_MANUAL_REVIEW` and do not generate a speculative patch for that finding.

Critical/High severity means automatic selection for analysis, not permission to invent a fix. Never invent graph nodes, callers, sources, sinks, or data-flow edges.

### Supported technology contexts

The remediation decision must be technology-aware. Supported contexts include Java/Spring, COBOL/DB2, Salesforce Apex, Salesforce triggers, Visualforce, Lightning Web Components, Angular/TypeScript, JavaScript and other source types when enough evidence exists. Do not apply a Java remediation pattern to COBOL or Salesforce merely because the CWE matches.

For Salesforce, recognize `.cls`, `.trigger`, `.page`, `.component`, LWC `.js`/`.html`, and relevant metadata XML. Preserve governor-limit behavior, sharing semantics, user/system execution mode, CRUD/FLS enforcement, authorization and business behavior. Never weaken `with sharing`, user-mode access, CRUD/FLS checks, escaping, or other existing security controls.

Record graph path, detected technology, confidence, evidence, root cause, remediation strategy and graph limitations in `selected-scan.json` and `remediation-report.md`.

## 8. File-by-file remediation

For each affected source file:

1. List all finding IDs, CWEs, severities, lines, procedures/methods, sources, and
   sinks reported for that file.
2. Open the source file once.
3. Correlate overlapping or related findings so one safe correction can address
   multiple findings where appropriate.
4. Trace only the minimum relevant flow for those findings:
   `untrusted source -> transformations -> validation/encoding -> sink`.
5. Apply the smallest technically correct set of changes for all findings in the
   file.
6. Preserve APIs, business behavior, database semantics, authentication,
   authorization, error behavior, record layouts, and logging intent.
7. Validate the consolidated file change once, or validate the narrowest affected
   module once when file-only validation is unavailable.
8. Record any finding that cannot be safely remediated and explain why.

Do not create independent, potentially conflicting edits for each finding in the
same file. Produce one coherent final file diff.

## 9. Preferred remediation patterns

- **CWE-79/80 XSS:** framework templating and context-aware output encoding;
  never bypass Angular sanitization.
- **CWE-89 SQL/SOQL injection:** use technology-specific parameterization. Java: prepared/named parameters. COBOL/DB2: static SQL and host variables where applicable. Salesforce Apex: prefer static SOQL with bind variables; when dynamic SOQL is genuinely required, prefer supported bind mechanisms such as `Database.queryWithBinds` where appropriate and strict allowlisting for identifiers/directions that cannot be bound. Never concatenate untrusted data into SQL/SOQL syntax.
- **CWE-113 CRLF/response splitting:** reject CR/LF and use framework-safe header
  APIs or strict allowlists.
- **CWE-117 log forging:** parameterized/structured logging and centralized
  CR/LF/control-character neutralization without removing security logs.
- **CWE-22 path traversal:** trusted base, resolve, normalize, and verify the
  final path remains inside the base.
- **CWE-78 command injection:** avoid shells; fixed executable plus separated,
  allowlisted arguments.
- **CWE-601 open redirect:** relative destinations or explicit allowlists.

Avoid blanket stripping, generic regex sanitizers, catch-and-ignore, hard-coded
safe values, security-control removal, or broad unrelated refactoring.

## 10. Generate one patch per source file

Derive `<scan-date>` from the selected scan's date directory, not from today's
clock date.

Create:

```text
.github/output/remediation/veracode/<project-or-module>/<scan-date>/
```

Generate exactly one standard unified-diff patch for each changed source file.
The patch filename must be based on the source file's basename, preserving the
original extension, followed by `.patch`.

Examples:

```text
CUAF610.cbl       -> CUAF610.cbl.patch
CustomerDao.java -> CustomerDao.java.patch
login.component.ts -> login.component.ts.patch
```

When two changed files in different directories have the same basename, avoid a
collision by adding a stable parent-directory qualifier:

```text
accounts-CUAF610.cbl.patch
payments-CUAF610.cbl.patch
```

Do not generate `finding-<id>.patch` files.

### Patch format and sidecar metadata

A `.patch` file must contain only Git-generated unified-diff content so that `git apply --check` can validate it reliably. NEVER prepend prose or `#` metadata comments to a patch and NEVER manually construct `---`, `+++`, or `@@` hunk lines/counts.

Generate patch bodies with Git, for example:

```text
git diff --binary --no-ext-diff -- <repository-relative-source-path>
```

or an isolated original/remediated comparison using `git diff --no-index` when source protection requires it.

Store finding IDs, CWEs, severity, technology, graph evidence, confidence, remediation strategy, status and validation results in `selected-scan.json` and `remediation-report.md`, not inside the `.patch` file.

Validate every generated patch from repository root:

```text
git apply --check --whitespace=nowarn <patch-file>
```

If validation fails, do not report the patch as successful. Regenerate it from coherent original/remediated content using Git.

## 11. Validation strategy

To reduce execution time:

- validate once per changed file when a compiler/linter supports it;
- otherwise validate once per affected module after all file changes are prepared;
- do not run the same build or test repeatedly for individual findings in one file;
- do not run a full repository build unless required by the project and no narrower
  validation exists;
- record commands, results, and limitations accurately.

## 12. Completion summary

Report:

- selected project/module;
- selected `results.json` path and scan date;
- total findings by severity, selected findings, and excluded findings;
- one row per changed source file showing its consolidated patch and finding IDs;
- remediated, skipped, and failed counts;
- validation performed;
- remediation output directory;
- requirement to run a fresh Veracode scan.


## Universal CWE handling (v7.1)

The remediation engine must accept every numeric CWE reported by Veracode. `remediation-rules.json` contains explicit high-confidence patterns plus a `default_rule` for valid/new CWE IDs. Absence of an explicit CWE entry is not an error.

Resolution order:
1. explicit CWE rule;
2. technology-specific rule;
3. generic evidence-based fallback;
4. `REQUIRES_MANUAL_REVIEW` when evidence is insufficient.

### Salesforce CWE-943
Trace user-controlled Apex/REST/Aura/LWC input to dynamic SOQL/SOSL. Prefer static queries with bind variables; use `Database.queryWithBinds` when appropriate; strictly allowlist dynamic identifiers, field/object names and sort choices that cannot be bound. Never weaken sharing, CRUD/FLS, authorization, user/system-mode intent or governor-limit behavior.
