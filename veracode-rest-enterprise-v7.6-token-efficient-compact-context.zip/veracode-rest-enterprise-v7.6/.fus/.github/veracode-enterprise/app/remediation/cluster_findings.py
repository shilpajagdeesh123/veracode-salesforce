#!/usr/bin/env python3
import argparse,json,re
from pathlib import Path

def norm(v): return str(v or '').strip()
def sink_family(s):
    s=norm(s)
    for x in ('Database.countQuery','Database.getQueryLocator','Database.queryWithBinds','Database.query'):
        if x.lower() in s.lower(): return x
    return s or 'unknown'
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--paths',required=True); ap.add_argument('--output',required=True); a=ap.parse_args()
    data=json.loads(Path(a.paths).read_text(encoding='utf-8-sig')); paths=data.get('paths',[])
    clusters={}
    for x in paths:
        if norm(x.get('severity')).lower() not in ('critical','high'): continue
        cwe=norm(x.get('cwe')); tech=norm(x.get('technology')); f=norm(x.get('file')); m=norm(x.get('method')); sink=sink_family(x.get('sink'))
        # For Salesforce CWE-943, cluster first by physical file because getRecords/count/save often share one query-construction root.
        if cwe=='CWE-943' and tech in ('apex','visualforce'):
            key='salesforce-cwe943|'+f
        else:
            key='{}|{}|{}|{}'.format(cwe,f,m,sink)
        c=clusters.setdefault(key,{'cluster_id':key,'cwe':cwe,'technology':tech,'file':f,'findings':[],'methods':[],'sinks':[],'root_cause_analysis_required':False})
        c['findings'].append(norm(x.get('finding_id')))
        if m and m not in c['methods']: c['methods'].append(m)
        if sink and sink not in c['sinks']: c['sinks'].append(sink)
        if cwe=='CWE-943' and tech in ('apex','visualforce'):
            c['root_cause_analysis_required']=True
            c['required_analysis']=[
              'Trace every variable contributing to final SOQL/SOSL text.',
              'Classify each dynamic component as value, object, field, operator, sort element, or free-form query fragment.',
              'Bind data values; allowlist structural elements.',
              'If client supplies a free-form WHERE/SOQL fragment, do not claim remediation from escaping/partial validation; require structured-filter/query-builder redesign or manual review.',
              'Check all related sinks in the same class/helper before generating consolidated remediation.'
            ]
    out={'schema_version':'7.5','cluster_count':len(clusters),'clusters':list(clusters.values())}
    op=Path(a.output); op.parent.mkdir(parents=True,exist_ok=True); op.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
    print('ROOT_CAUSE_CLUSTERS='+str(len(clusters))); print('CLUSTER_FILE='+str(op))
if __name__=='__main__': main()
